<?php
header("Location: registration.php");
